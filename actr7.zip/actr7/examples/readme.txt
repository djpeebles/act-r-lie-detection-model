The files in this directory are examples of using some of the
advanced capabilities of the software which are not described 
in the tutorial.  They include things like running multiple models
simultaneously, adding new perceptual/motor devices, or creating
new modules for the system.  Most of the models found here are
not good models.  They are just simple demonstrations that show 
how some particular advanced capability may be used.

For those just starting to learn ACT-R, the texts and models in
the tutorial directory are the best place to start.