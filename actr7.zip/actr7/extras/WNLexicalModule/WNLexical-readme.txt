#|
ACT-R/WN-LEXICAL :: WNLexical module

This directory contains the module file "WNLexical_3-0-2.lisp", which must be copied to the folder "actr7/modules/". A models folder also contains act-r model examples.

In addition, the most recent package "WNLexicalData" must be downloaded and installed by following the instructions in the "WNLexicalData" package.
The WNLexical data files can be obtained from http://sourceforge.net/projects/actr-wn-lexical/

Before loading act-r 7, you should have the following files present: 

actr7/WNLexicalData/WNChunks.data
actr7/WNLexicalData/WNChunksIndexes.data
actr7/modules/WNLexical_3-0-2.lisp

|#

:eof
